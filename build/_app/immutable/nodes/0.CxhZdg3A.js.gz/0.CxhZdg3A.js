import{v as e,f as r,B as o,b as s}from"../chunks/B-ADY1me.js";const n=Object.freeze(Object.defineProperty({__proto__:null,csr:!0,prerender:!0,ssr:!1},Symbol.toStringTag,{value:"Module"}));function t(n,t){var a=e(),l=r(a);o(l,t,"default",{},null),s(n,a)}export{t as component,n as universal};
//# sourceMappingURL=0.CxhZdg3A.js.map
