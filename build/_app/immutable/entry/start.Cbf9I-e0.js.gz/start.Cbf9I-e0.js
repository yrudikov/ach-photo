import{l as s,a}from"../chunks/YablEMNB.js";export{s as load_css,a as start};
//# sourceMappingURL=start.Cbf9I-e0.js.map
